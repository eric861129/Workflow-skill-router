# Workflow Skill Router Template Package

This package contains public-safe, copyable skill routing material:

- `starter/workflow-skill-router/`: a blank router skill you can install first.
- `examples/common-engineering-routing/`: realistic route examples with concrete skill names.
- `sample-skills/`: complete sample `SKILL.md` folders that pair with the common routes.

Install the blank router into your agent's skill directory, then use the common engineering example and sample skills as references while filling your own `references/skill-tree.md`.

For Codex on Windows, the install target is usually:

```text
C:\Users\<you>\.codex\skills\workflow-skill-router
```
