---
name: api-guidelines-skill
description: Use when designing, reviewing, or refactoring REST API style, resource naming, route shape, versioning, pagination, filtering, sorting, error semantics, compatibility, idempotency, HTTP methods, or API governance beyond a project-specific contract.
---


# API Guidelines Skill

## Purpose


## API design checklist

- Model resources with stable nouns, not UI actions.
- Use HTTP methods consistently: `GET` read, `POST` create/command, `PUT` replace, `PATCH` partial update, `DELETE` delete or deactivate when business rules allow.
- Keep route names predictable and plural unless the project already has a stronger convention.
- Separate collection filters from resource identifiers.
- Define pagination, sorting, and filtering explicitly, including defaults and maximum page sizes.
- Keep response envelopes, error codes, trace IDs, and validation errors consistent with the owning API.
- Preserve backward compatibility unless the user explicitly approves a breaking change.
- Document idempotency expectations for retryable commands and external integrations.

## ApiCenter usage

When the target is ApiCenter:

3. Use this skill only for broader REST tradeoffs: route shape, resource boundaries, compatibility, and public contract readability.

## Review questions

- Can a frontend developer predict the route and DTO from surrounding APIs?
- Is the API scoped to the caller's permissions and data ownership?
- Are list endpoints safe for large datasets?
- Are errors useful without leaking private implementation or sensitive data?
- Does the change require generated clients, frontend types, docs, or migration notes?

## Verification

For code changes, run the repo's contract, snapshot, and integration checks. For design-only answers, include example routes and DTO names but mark them as proposed until verified against the live repo.
