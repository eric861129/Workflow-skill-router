---
name: docker-compose-local-dev-skill
description: Public-safe template copy of the docker-compose-local-dev-skill skill.
---


# Docker Compose Local Dev Skill

## Purpose


## Before editing

1. Inspect existing `docker-compose*.yml`, `.env*`, docs, and app configuration.
3. Confirm whether the target service should be a container or an existing Windows/IIS/SQL dependency.
4. Never commit real secrets or production-like connection strings.

## Compose design rules

- Keep service names stable and descriptive.
- Use explicit ports only when humans or host apps need them.
- Prefer named volumes for durable local data; explain reset steps instead of deleting volumes automatically.
- Add health checks for databases, queues, mail tools, and dependent services when startup order matters.
- Keep env files as templates with placeholder values.
- Separate local-only tooling from staging/production deployment scripts.
- Do not use destructive cleanup commands. If many containers/volumes need removal, ask the user to perform the cleanup intentionally.


Good local-dev candidates:

- SQL Server dev/test container when it does not replace the authoritative DEV database.
- Mail capture tool for testing SMTP flows without sending real messages.
- Redis/cache or queue simulators when a feature needs them.
- Observability helpers for logs/metrics in local debugging.

Bad candidates:

- Production IIS deployment.
- Secret distribution.
- A fake DB that is presented as authoritative live DEV evidence.

## Verification

Use the installed Docker CLI if available:

```powershell
docker compose config
docker compose up --wait
docker compose ps
docker compose logs <service>
git diff --check
```

If Docker is not installed or the daemon is unavailable, still validate YAML shape and report that runtime proof was blocked.
