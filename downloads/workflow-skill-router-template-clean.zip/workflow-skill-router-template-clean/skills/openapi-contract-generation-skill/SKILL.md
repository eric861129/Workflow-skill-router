---
name: openapi-contract-generation-skill
description: Use when generating, validating, diffing, or consuming OpenAPI contracts, API clients, TypeScript models, SDKs, schema snapshots, contract drift reports, or backend-to-frontend synchronization workflows.
---


# OpenAPI Contract Generation Skill

## Purpose

Use this skill when OpenAPI is the artifact that keeps backend and frontend aligned. It complements `openapi-to-typescript`; use it for the whole contract workflow, not only TypeScript output.

## Contract workflow

1. Find the authoritative OpenAPI source from the repo, build output, or running API.
2. Verify whether the contract is generated, committed, snapshot-tested, or both.
3. Diff contract changes before regenerating clients.
4. Regenerate client/types with the repo's existing tool and config.
5. Update consuming code, mocks, docs, and tests in the same branch.
6. Run contract snapshots and frontend typecheck/build.

## Guardrails

- Do not hand-edit generated clients unless the repo explicitly owns them as source.
- Do not hide backend breaking changes by loosening frontend types.
- Keep enum/string literal changes visible in reviews.
- Check nullable/optional semantics carefully; they often cause runtime bugs after generation.
- Validate auth metadata, route casing, operation IDs, response envelopes, and error shapes.
- If generated output is large, summarize the semantic contract changes instead of pasting generated code into the response.


- Use `openapi-to-typescript` when the concrete task is TypeScript type generation.

## Verification

Use repo scripts when available. Typical evidence:

```powershell
npm.cmd run release:gate
git diff --check
```

If a live API is needed to produce the contract, report the exact URL/environment and do not assume staging equals source.
