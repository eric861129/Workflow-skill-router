---
name: tailwind-design-token-skill
description: Use when designing, reviewing, or refactoring Tailwind CSS, utility classes, design tokens, responsive spacing, semantic colors, dark mode, typography, class composition, or token-driven UI consistency in frontend projects.
---


# Tailwind Design Token Skill

## Purpose

Use this skill when Tailwind or token-driven utility CSS affects UI consistency. It is strongest for shared design tokens, repeated layouts, responsive spacing, semantic color decisions, and class hygiene.

## When to use

- A page has repeated hard-coded colors, spacing, shadows, radii, or typography.
- A shared token should replace one-off utility values.
- Dark mode, theme switching, or brand color semantics are involved.
- A UI looks visually inconsistent across apps or breakpoints.
- Tailwind class strings are becoming unreadable or duplicated.

Do not use this skill if the project does not use Tailwind or utility-class styling.

## Token-first rules

- Prefer semantic tokens over raw colors when the project has token support.
- Keep one-off arbitrary values rare and justified.
- Use consistent spacing scales, radii, shadows, and typography across repeated surfaces.
- Avoid class soup by extracting stable variants into components, utilities, or tokenized props.
- Preserve accessibility: color contrast, visible focus, reduced motion, readable line length, and responsive text wrapping.
- Keep Traditional Chinese copy length in mind; labels and buttons must not rely on English-length text.


- Pair with `frontend-design`, `minimalist-ui`, or `design-taste-frontend` for visual direction.
- Pair with `storybook-design-system-skill` when tokens should be demonstrated across component states.

## Review checklist

- Does the component use semantic token names where available?
- Does the layout survive mobile, tablet, desktop, and long Traditional Chinese text?
- Are focus, hover, disabled, loading, error, and permission states styled consistently?
- Are utilities duplicated enough to justify a component or variant abstraction?
- Does the change stay within the existing design system instead of inventing a new palette?

## Verification

Run the smallest relevant frontend checks and include browser proof for visible UI changes:

```powershell
npm.cmd run typecheck
npm.cmd run test:unit
npm.cmd run build
git diff --check
```
