---
name: storybook-design-system-skill
description: Public-safe template copy of the storybook-design-system-skill skill.
---


# Storybook Design System Skill

## Purpose

Use this skill when UI work needs a durable component workshop instead of only page-level implementation. It is strongest for `packages/ui`, reusable form/table/modal components, design tokens, interaction states, and frontend onboarding docs.

## When to use

- A component has many states: loading, empty, error, disabled, permission denied, responsive, long Traditional Chinese text, or role-specific variants.
- A UI regression is hard to see from unit tests alone.
- A design system or component catalog is being introduced, cleaned up, or reviewed.

Do not add Storybook infrastructure just because a page changed. Use existing repo patterns first.

## Component story rules

- Put shared stories near the component or in the repo's existing Storybook location.
- Use fake but realistic Traditional Chinese data. Never use real student, parent, staff, phone, email, or ID data.
- Show accessibility-relevant states: keyboard focus, disabled controls, labels, error text, contrast-sensitive variants, and responsive layouts.
- Include permission and RBAC-driven states for Admin Web components when relevant.
- Keep stories deterministic. Avoid live API calls, current dates, random IDs, or network-only fixtures unless the repo already has a stable mock layer.
- Prefer tokens and existing components over story-only styling.


- `packages/ui`: business-neutral primitives and reusable shell components.
- `packages/design-tokens`: color, spacing, typography, and semantic token examples.
- `packages/i18n`: copy-heavy components should prove Traditional Chinese length and layout.
- App folders: use stories for app-specific components only when they are complex enough to justify isolated review.

## Review checklist

- The story names match the user-visible workflow or state.
- Stories cover the hard cases, not only the happy path.
- No real personal data appears in fixtures.
- Components remain usable outside Storybook.
- Storybook setup does not slow normal `typecheck`, `test:unit`, or `release:gate` unless intentionally wired into CI.

## Verification

Use the repo's real scripts. Typical checks:

```powershell
npm.cmd run storybook
npm.cmd run build-storybook
npm.cmd run typecheck
npm.cmd run test:unit
git diff --check
```

If Storybook is not installed, first produce an adoption plan and package impact summary before editing dependencies or CI.
