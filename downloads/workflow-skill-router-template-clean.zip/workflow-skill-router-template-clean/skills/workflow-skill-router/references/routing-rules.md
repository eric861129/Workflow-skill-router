# Routing Rules

## Priority

1. Respect explicit user requests. If the user names a SKILL or plugin, include it unless it is unavailable.
3. Prefer connector/plugin SKILLs when external systems are the core task.
4. Prefer local custom SKILLs for broad engineering judgment and repository work.
5. Prefer system SKILLs for OpenAI docs, image generation, plugin creation, skill creation, and skill installation.
6. Use broad Superpowers meta SKILLs only when the workflow is explicitly requested or clearly required.

## Skill Count

- Use one primary SKILL for narrow tasks.
- Use two to four SKILLs for cross-domain work.
- If more than four seem useful, choose the four that cover distinct phases: clarify, design, implement, verify.
- Do not include two skills that do the same job unless one is a connector and one is a local review/process skill.

## Conflict Handling

- `systematic-debugging` vs `superpowers:systematic-debugging`: use local `systematic-debugging` by default; use the Superpowers version when following the Superpowers workflow.
- `executing-plans` vs `superpowers:executing-plans`: use local `executing-plans` for normal plan execution; use the Superpowers version when the user asks for Superpowers or subagent-driven execution.
- `receiving-code-review` vs `github:gh-address-comments`: use GitHub skill to fetch/resolve PR comments; use receiving-code-review to reason about whether comments are valid.
- `vue-composition-patterns-skill` vs `vue-expert`: use vue-expert for general Vue 3 implementation; use vue-composition-patterns-skill when extracting or reviewing composables, reactivity boundaries, watchers, lifecycle effects, VueUse-style utilities, route-aware logic, shared state, or browser API wrappers.
- `openapi-contract-generation-skill` vs `openapi-to-typescript`: use openapi-contract-generation-skill for the full schema lifecycle: source, diff, validation, snapshot, SDK/client generation, and contract drift reporting. Use openapi-to-typescript when the concrete task is TypeScript model generation only.
- `owasp-secure-school-system-skill` vs `codex-security:*`: use owasp-secure-school-system-skill as a school-system risk lens for auth, RBAC, personal data, student/parent/staff data, public links, CORS, secrets, files, and deployment exposure. Use codex-security skills for formal scans, PR diff scans, threat models, finding validation, and fixes.
- `frontend-design` vs `build-web-apps:frontend-app-builder`: use frontend-app-builder for full new frontend apps; use frontend-design for visual design quality and targeted UI.
- Local Taste UI aliases: output Codex-displayed names in `Use SKILL`, not folder names. Aliases are `taste-skill` -> `design-taste-frontend`, `redesign-skill` -> `redesign-existing-projects`, `minimalist-skill` -> `minimalist-ui`, `image-to-code-skill` -> `image-to-code`, `soft-skill` -> `high-end-visual-design`, and `gpt-tasteskill` -> `gpt-taste`.
- `design-taste-frontend` vs `redesign-existing-projects`: use design-taste-frontend for new public-facing visual direction; use redesign-existing-projects when upgrading an existing website/app without breaking behavior.
- `high-end-visual-design` vs `gpt-taste`: use high-end-visual-design for premium PortalWeb, parent/student/teacher portals, and school-facing polish. Use gpt-taste only when the request is a landing page, admissions/event page, Awwwards-like page, GSAP motion, scroll storytelling, or the user explicitly asks for a showpiece.
- `minimalist-ui` vs `high-end-visual-design`/`gpt-taste`: use minimalist-ui for Admin Web, internal school systems, dashboards, forms, lists, permission pages, or content-heavy workflows. Avoid high-end-visual-design/gpt-taste for these unless the user explicitly asks for a more expressive treatment.
- `imagegen-frontend-web`, `imagegen-frontend-mobile`, and `image-to-code`: use imagegen skills when the task needs design reference images or concepts first; use image-to-code when implementing from a screenshot, mockup, or generated visual target. For a two-step visual workflow, route concept generation before code implementation.
- `storybook-design-system-skill` vs `design-system-starter`: use storybook-design-system-skill when the task needs component stories, isolated UI states, visual review surfaces, or Storybook adoption/maintenance. Use design-system-starter for token/component-system architecture without Storybook-specific execution.
- `tailwind-design-token-skill` vs `frontend-design`: use tailwind-design-token-skill for utility CSS, semantic tokens, class composition, responsive spacing, dark mode, and Tailwind class hygiene. Use frontend-design for broader visual and interaction design.
- `playwright` vs `browser:control-in-app-browser`: use browser:control-in-app-browser for the Codex in-app browser and local visual verification; use playwright for scripted browser automation from terminal.
- `chrome:control-chrome` vs `browser:control-in-app-browser` vs `playwright`: use Chrome only when the task needs the user's existing Chrome login state, cookies, extensions, current tabs, or Chrome-specific behavior. Use Browser for local app navigation and visual QA. Use Playwright for repeatable scripted browser automation.
- `documents`, `spreadsheets`, `presentations`, `pdf`: choose by file type; do not replace them with generic documentation skills when file rendering matters.
- Data Analytics vs documents/spreadsheets: use `data-analytics:*` when the user needs KPI definitions, metric diagnosis, dashboards, charts, quantified reports, or source-backed analysis. Use `spreadsheets:Spreadsheets` as supporting when the deliverable or source is an Excel/Google Sheets-style workbook; use `documents:documents` only when Word/Docs rendering is the main artifact.
- Security review vs normal code review: use `codex-security:security-diff-scan` for PRs, changed files, auth/RBAC/API diffs, secrets, data exposure, or deployment-sensitive changes. Use `codex-security:security-scan` for wider repository/module scans, and `codex-security:threat-model` when designing a new sensitive feature before implementation. Keep `receiving-code-review` for general maintainability feedback.
- Google Workspace routing: use `google-drive:google-drive` as the entrypoint for Drive files and then select Docs, Sheets, Slides, or comments by artifact type. Use `gmail:gmail` for mailboxes and threads. Use `google-calendar:google-calendar` for scheduling, availability, meeting prep, and calendar briefs. Prefer Google connector skills over web search when the user's connected Google data is the source of truth.
- Product Design image-to-code vs local image-to-code: use `product-design:image-to-code` when working inside the Product Design plugin flow or turning a selected Product Design image into an interactive prototype. Use local `image-to-code` for normal repository implementation from screenshots, mockups, or image references.
- Creative Production vs Product Design vs ckm brand skills: use `creative-production:*` for campaign ideas, ads, offer positioning, moodboards, shot/scene exploration, logo routes, and business-safe generated visuals. Use Product Design for application/product UX prototypes. Use `ckm:*` skills for local brand systems, design tokens, banners, and durable identity documentation.

## Output Examples

Backend API:

```text
原因：api-contract 對齊 ApiCenter 合約規則；core 先做 repo 與編碼安全檢查；api-designer 補 REST 判斷；openapi-to-typescript 協助前後端合約同步。
```

Frontend debug:

```text
路由：前端/Web/UI > Debug > Browser 驗證
使用 SKILL：build-web-apps:frontend-testing-debugging, browser:control-in-app-browser, systematic-debugging
原因：frontend-testing-debugging 對應渲染問題；browser:control-in-app-browser 做本機瀏覽器驗證；systematic-debugging 保持根因分析。
```

PortalWeb public-facing UI:

```text
路由：前端/Web/UI > 對外平台或 PortalWeb > 家長、學生、導師站台 UI UX
使用 SKILL：design-taste-frontend, high-end-visual-design, frontend-design, vue-expert
```

Admin Web internal UI:

```text
路由：前端/Web/UI > Admin Web 或校務後台 > 表單、列表、權限頁、資訊密度
使用 SKILL：minimalist-ui, frontend-design, vue-expert, browser:control-in-app-browser
原因：minimalist-ui 保持專業清楚；frontend-design 補互動與視覺品質；vue-expert 對齊 Vue 3 實作；browser:control-in-app-browser 做實際畫面驗證。
```

Image-first website workflow:

```text
路由：前端/Web/UI > 先看視覺稿 > 分段網頁設計參考圖
使用 SKILL：imagegen-frontend-web, design-taste-frontend, frontend-design, image-to-code
原因：imagegen-frontend-web 先產出每個 section 的參考圖；design-taste-frontend 控制整體 taste；frontend-design 保持可實作性；image-to-code 在確認視覺後接手實作。
```


```text
```


```text
```


```text
```

Backend to frontend sync:

```text
```


```text
```

Legacy migration:

```text
原因：legacy-migration-playbook 先分辨舊系統證據與新系統落點；spec-miner 抽取舊規格；apicenter-core 對齊後端邊界；web-monorepo-core 對齊前端站台。
```

DEV data or RBAC mismatch:

```text
原因：dev-data-rbac-verifier 先查 live data 與權限鏈；systematic-debugging 保持根因分析；sql-pro 補查詢判斷；apicenter-core 對齊 ApiCenter runtime。
```


```text
```


```text
原因：owasp-secure-school-system-skill 套用校務系統安全風險視角；security-diff-scan 做差異掃描；api-contract 查 API 權限與合約；dev-data-rbac-verifier 查 live 權限資料鏈。
```

Storybook and Tailwind design system:

```text
路由：前端/Web/UI > Storybook Design System > component catalog、states、visual regression、shared UI docs
```

Local Docker Compose dev stack:

```text
路由：Local Dev/Docker Compose > SQL、cache、mail、ports、volumes、health checks
```

Security-sensitive change:

```text
路由：Security/Pull Request 或差異掃描 > 權限、Auth、RBAC、資料外洩風險
使用 SKILL：codex-security:security-diff-scan, receiving-code-review, systematic-debugging, github:github
原因：security-diff-scan 聚焦安全風險；receiving-code-review 補一般 review 判斷；systematic-debugging 追根因；github:github 查 PR 與遠端狀態。
```

Google Workspace file task:

```text
路由：Connector/協作 > Google Drive > Drive、Docs、Sheets、Slides 檔案協作
使用 SKILL：google-drive:google-drive, google-drive:google-docs, google-drive:google-sheets, google-drive:google-slides
原因：google-drive 是 Drive 入口；google-docs 處理文件；google-sheets 處理試算表；google-slides 處理簡報。
```

Chrome logged-in QA:

```text
路由：Connector/協作 > Chrome > 使用者既有登入狀態與 Chrome-only QA
使用 SKILL：chrome:control-chrome, browser:control-in-app-browser, playwright, systematic-debugging
原因：chrome:control-chrome 使用既有登入狀態；browser:control-in-app-browser 可補本機視覺驗證；playwright 可做腳本化檢查；systematic-debugging 保持根因分析。
```

Product design exploration:

```text
路由：設計/品牌/影音 > Product Design > brief、方向發散、可 review 的產品原型
使用 SKILL：product-design:get-context, product-design:ideate, product-design:image-to-code, frontend-design
原因：get-context 是產品設計 brief 入口；ideate 產生方向；image-to-code 可把選定 mockup 變成互動原型；frontend-design 補可實作品質。
```

Creative production exploration:

```text
路由：設計/品牌/影音 > Creative Production > campaign、offer、positioning、moodboard、logo、ads
使用 SKILL：creative-production:explore, creative-production:positioning-explorer, creative-production:moodboard-explorer, creative-production:offer-explorer
原因：explore 是創意探索入口；positioning-explorer 聚焦定位；moodboard-explorer 產視覺方向；offer-explorer 釐清可行提案。
```

Simple command:

```text
不需要額外路由：這是單一步驟 shell 查詢，直接執行即可。
```

## Safety Defaults

- For filesystem operations, preserve the user's no bulk-delete rule.
- For repo work, inspect existing structure before deciding implementation.
- For frontend work, include browser or Playwright verification when UI behavior matters.
- For docs work, fit the repo's existing information architecture before writing new content.
- For connector work, use the connector skill and do not simulate unavailable live data.
