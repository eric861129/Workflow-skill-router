# Workflow Skill Tree

Use this tree to choose a small SKILL set. Format:

`任務性質 -> 工作階段 -> 技術領域 -> Primary + Supporting SKILLs`

Pick one primary SKILL and up to three supporting SKILLs.

## Skill Inventory Summary

This router is based on the SKILLs currently available in this Codex environment. It should route to a small working set, not replace the underlying SKILLs.

| Source | SKILLs | Role | Routing Notes |
| --- | --- | --- | --- |
| Custom | `agent-md-refactor`, `api-designer`, `api-guidelines-skill`, `architecture-designer`, `c4-architecture`, `ckm:*`, `cloud-architect`, `code-documenter`, `commit-work`, `csharp-developer`, `database-*`, `dependency-updater`, `design-system-starter`, `devops-engineer`, `docker-compose-local-dev-skill`, `doc-coauthoring`, `dotnet-core-expert`, `executing-plans`, `file-organizer`, `finishing-a-development-branch`, `flutter-expert`, `frontend-design`, `karpathy-guidelines`, `mermaid-diagrams`, `openapi-contract-generation-skill`, `openapi-to-typescript`, `pdf`, `playwright`, `qa-test-planner`, `receiving-code-review`, `requirements-clarity`, `session-handoff`, `spec-miner`, `sql-pro`, `storybook-design-system-skill`, `systematic-debugging`, `tailwind-design-token-skill`, `ui-ux-pro-max`, `vue-composition-patterns-skill`, `vue-expert`, `workflow-skill-router`, `writing-clearly-and-concisely` | Local engineering, architecture, API governance, UI, design-system, docs, local dev, debugging, and workflow judgment | Prefer these for repository work, implementation planning, local coding, durable documentation, UI systems, API contract work, and local developer environments. |
| System | `imagegen`, `openai-docs`, `plugin-creator`, `skill-creator`, `skill-installer` | Built-in Codex capabilities | Use for OpenAI docs, image generation, plugin work, and skill creation or installation. |
| Taste UI | `design-taste-frontend`, `redesign-existing-projects`, `minimalist-ui`, `image-to-code`, `imagegen-frontend-web`, `imagegen-frontend-mobile`, `high-end-visual-design`, `gpt-taste` | Public-facing UI taste, premium redesign, image-first website references, and mobile concept direction | Prefer these for PortalWeb, parent/student/teacher portals, landing pages, polished school-facing experiences, and visually important UI/UX work. Keep the selected set small. |
| Plugin / Connector | `browser:control-in-app-browser`, `chrome:control-chrome`, `build-web-apps:*`, `circleci:*`, `codex-security:*`, `creative-production:*`, `data-analytics:*`, `documents:documents`, `github:*`, `gmail:*`, `google-calendar:*`, `google-drive:*`, `hyperframes:*`, `notion:*`, `presentations:Presentations`, `product-design:*`, `remotion:remotion-best-practices`, `spreadsheets:Spreadsheets`, `teams:*` | External runtimes, live connectors, browser automation, file-format tooling, CI, repo, security, analytics, collaboration, product design, creative exploration, and media workflows | Prefer these when the task depends on live external systems, rendered browser behavior, Chrome login state, Google/GitHub/Teams/Notion data, Office files, CI providers, security review, data analysis, product design, creative production, or plugin-specific runtimes. |
| Meta Workflow | `superpowers:*`, `executing-plans`, `requirements-clarity`, `systematic-debugging`, `receiving-code-review`, `session-handoff`, `finishing-a-development-branch` | Process control for planning, debugging, review, execution, handoff, and completion | Use sparingly. Prefer narrow local workflow skills by default; use broad Superpowers variants when explicitly requested or when their method is the task. |

High-value default SKILLs: `requirements-clarity`, `api-designer`, `architecture-designer`, `csharp-developer`, `frontend-design`, `vue-expert`, `design-taste-frontend`, `redesign-existing-projects`, `systematic-debugging`, `doc-coauthoring`, `code-documenter`, `playwright`, `browser:control-in-app-browser`, `commit-work`.

Alias note: route outputs must use Codex-displayed SKILL names. Local folder aliases are `taste-skill` -> `design-taste-frontend`, `redesign-skill` -> `redesign-existing-projects`, `minimalist-skill` -> `minimalist-ui`, `image-to-code-skill` -> `image-to-code`, `soft-skill` -> `high-end-visual-design`, and `gpt-tasteskill` -> `gpt-taste`.


Low-frequency or specialized SKILLs: `hyperframes:*`, `remotion:remotion-best-practices`, `creative-production:*`, `product-design:*`, `circleci:chunk`, `ckm:banner-design`, `file-organizer`, `plugin-creator`, `skill-installer`.

Easily over-triggered SKILLs: `workflow-skill-router`, `superpowers:*`, `ui-ux-pro-max`, `ckm:design`, `writing-clearly-and-concisely`, `mermaid-diagrams`. Use them only when they materially improve the current task.

## 需求 / 規劃 / 任務拆解

- 需求 / 釐清 / 複雜功能: Primary: `requirements-clarity`; Supporting: `superpowers:brainstorming`, `superpowers:writing-plans`
- 規劃 / 實作計畫 / 多階段工程: Primary: `executing-plans`; Supporting: `superpowers:executing-plans`, `karpathy-guidelines`
- 收尾 / 交接 / 分支完成: Primary: `session-handoff`; Supporting: `finishing-a-development-branch`, `superpowers:verification-before-completion`, `commit-work`



## 架構 / API / 後端

- 架構 / 系統設計 / 高階決策: Primary: `architecture-designer`; Supporting: `c4-architecture`, `mermaid-diagrams`, `cloud-architect`
- API / 合約設計 / REST 或 GraphQL: Primary: `api-designer`; Supporting: `openapi-to-typescript`, `code-documenter`
- 後端 / C# 或 .NET / 實作: Primary: `csharp-developer`; Supporting: `dotnet-core-expert`, `database-schema-designer`, `qa-test-planner`

## 資料庫 / SQL

- 資料庫 / Schema / Migration: Primary: `database-schema-designer`; Supporting: `sql-pro`, `build-web-apps:supabase-postgres-best-practices`
- 資料庫 / 效能 / 慢查詢: Primary: `database-optimizer`; Supporting: `sql-pro`, `systematic-debugging`
- 資料合約 / API 與 DB 邊界: Primary: `api-designer`; Supporting: `openapi-to-typescript`, `database-schema-designer`

## 前端 / Web / UI

- 前端 / 新 App 或頁面 / Vue 或通用 Web: Primary: `build-web-apps:frontend-app-builder`; Supporting: `frontend-design`, `ui-ux-pro-max`, `vue-expert`
- 前端 / 對外平台或 PortalWeb / 家長、學生、導師站台 UI UX: Primary: `design-taste-frontend`; Supporting: `high-end-visual-design`, `frontend-design`, `vue-expert`
- 前端 / 招生形象頁、活動頁、Landing / Awwwards 或 GSAP 動態敘事: Primary: `gpt-taste`; Supporting: `design-taste-frontend`, `high-end-visual-design`, `imagegen-frontend-web`
- 前端 / Admin Web 或校務後台 / 表單、列表、權限頁、資訊密度: Primary: `minimalist-ui`; Supporting: `frontend-design`, `vue-expert`, `browser:control-in-app-browser`
- 前端 / 既有網站改版 / 視覺品質提升且不破壞功能: Primary: `redesign-existing-projects`; Supporting: `frontend-design`, `vue-expert`, `browser:control-in-app-browser`
- 前端 / 先看視覺稿 / 分段網頁設計參考圖: Primary: `imagegen-frontend-web`; Supporting: `design-taste-frontend`, `frontend-design`, `image-to-code`
- 前端 / Image-first 網頁實作 / 截圖、設計稿、AI 視覺稿到程式碼: Primary: `image-to-code`; Supporting: `imagegen-frontend-web`, `frontend-design`, `browser:control-in-app-browser`
- 前端 / UI 系統 / Component styling: Primary: `ckm:ui-styling`; Supporting: `ckm:design-system`, `design-system-starter`, `tailwind-design-token-skill`
- 前端 / Storybook Design System / component catalog、states、visual regression、shared UI docs: Primary: `storybook-design-system-skill`; Supporting: `design-system-starter`, `tailwind-design-token-skill`, `frontend-design`
- 前端 / Debug / Browser 驗證: Primary: `build-web-apps:frontend-testing-debugging`; Supporting: `browser:control-in-app-browser`, `playwright`, `systematic-debugging`
- 前端 / React 或 Next.js / Performance: Primary: `build-web-apps:react-best-practices`; Supporting: `build-web-apps:stripe-best-practices`

## Flutter / 行動 App

- 行動 / Flutter App / UI 與狀態管理: Primary: `flutter-expert`; Supporting: `ui-ux-pro-max`, `api-designer`, `openapi-to-typescript`
- 行動 / Mobile App 視覺概念 / Flutter 或跨平台畫面方向: Primary: `imagegen-frontend-mobile`; Supporting: `flutter-expert`, `design-taste-frontend`, `ui-ux-pro-max`
- 行動 / 測試與驗收 / Bug 修復: Primary: `qa-test-planner`; Supporting: `systematic-debugging`

## 文件 / 知識 / 內容產出

- 文件 / 技術文件 / 可讀性與結構: Primary: `doc-coauthoring`; Supporting: `code-documenter`, `writing-clearly-and-concisely`, `mermaid-diagrams`
- 文件 / 架構圖 / C4 或流程圖: Primary: `c4-architecture`; Supporting: `mermaid-diagrams`, `architecture-designer`
- 文件 / Office 檔案 / Word、Excel、Slides、PDF: Primary: `documents:documents`; Supporting: `spreadsheets:Spreadsheets`, `presentations:Presentations`, `pdf`
- 知識庫 / Notion / 研究、紀錄、規格轉實作: Primary: `notion:notion-research-documentation`; Supporting: `notion:notion-knowledge-capture`, `notion:notion-spec-to-implementation`

## 資料分析 / KPI / Dashboard

- 資料分析 / 校務 KPI 或營運報表 / 指標定義、趨勢、異常解釋: Primary: `data-analytics:kpi-reporting`; Supporting: `data-analytics:metric-diagnostics`, `data-analytics:product-business-analysis`, `spreadsheets:Spreadsheets`
- 資料分析 / Dashboard 或視覺化 / 管理儀表板、招生、訪客、權限使用分析: Primary: `data-analytics:build-dashboard`; Supporting: `data-analytics:visualize-data`, `data-analytics:design-kpis`, `spreadsheets:Spreadsheets`
- 資料分析 / 對外或主管報告 / 可交付分析報告、資料來源說明: Primary: `data-analytics:build-report`; Supporting: `data-analytics:visualize-data`, `writing-clearly-and-concisely`

## Debug / Review / CI / GitHub

- Debug / Bug 調查 / 根因分析: Primary: `systematic-debugging`; Supporting: `superpowers:systematic-debugging`, `playwright`, `browser:control-in-app-browser`
- Review / PR 意見 / Code review: Primary: `receiving-code-review`; Supporting: `github:gh-address-comments`, `superpowers:requesting-code-review`
- Security / Pull Request 或差異掃描 / 權限、Auth、RBAC、資料外洩風險: Primary: `codex-security:security-diff-scan`; Supporting: `receiving-code-review`, `systematic-debugging`, `github:github`
- Security / Repo 或模組安全盤點 / 威脅模型、攻擊面、修補驗證: Primary: `codex-security:security-scan`; Supporting: `codex-security:threat-model`, `codex-security:fix-finding`, `systematic-debugging`
- CI / GitHub Actions 或 CircleCI / 失敗修復: Primary: `github:gh-fix-ci`; Supporting: `circleci:circleci-builds`, `circleci:circleci-config`, `devops-engineer`
- Git / Commit 或 PR / 發佈: Primary: `commit-work`; Supporting: `github:yeet`, `github:github`

## DevOps / Cloud / 依賴

- 部署 / Infra / Cloud: Primary: `devops-engineer`; Supporting: `cloud-architect`, `circleci:circleci-cli`, `circleci:chunk`
- 依賴 / 套件更新 / 風險控管: Primary: `dependency-updater`; Supporting: `systematic-debugging`, `qa-test-planner`

## 設計 / 品牌 / 影音

- 設計 / 品牌與視覺 / Banner、UI、Identity: Primary: `ckm:brand`; Supporting: `ckm:design`, `ckm:banner-design`, `imagegen`
- Product Design / 產品設計探索 / brief、方向發散、可 review 的產品原型: Primary: `product-design:get-context`; Supporting: `product-design:ideate`, `product-design:image-to-code`, `frontend-design`
- Product Design / 選定 mockup 實作 / screenshot、mockup、Image Gen 到互動產品畫面: Primary: `product-design:image-to-code`; Supporting: `product-design:get-context`, `frontend-design`, `browser:control-in-app-browser`
- Creative Production / 商業創意探索 / campaign、offer、positioning、moodboard、logo、ads: Primary: `creative-production:explore`; Supporting: `creative-production:positioning-explorer`, `creative-production:moodboard-explorer`, `creative-production:offer-explorer`
- Creative Production / 視覺素材打磨 / business-safe 生成圖、場景、鏡頭、廣告素材: Primary: `creative-production:generative-polish`; Supporting: `creative-production:shot-explorer`, `creative-production:scene-explorer`, `creative-production:ads-explorer`
- 影片 / 動畫 / 網站轉影片: Primary: `hyperframes:hyperframes`; Supporting: `hyperframes:gsap`, `hyperframes:website-to-hyperframes`, `remotion:remotion-best-practices`
- HyperFrames / 工具與 Registry / CLI 操作: Primary: `hyperframes:hyperframes-cli`; Supporting: `hyperframes:hyperframes-registry`

## Connector / 協作

- Teams / 訊息、摘要、任務 / 工作協作: Primary: `teams:teams`; Supporting: `teams:teams-messages`, `teams:teams-daily-digest`, `teams:teams-planner-task-management`
- Teams / 通知與回覆 / triage: Primary: `teams:teams-notification-triage`; Supporting: `teams:teams-reply-drafting`, `teams:teams-channel-summarization`
- Google Drive / Drive、Docs、Sheets、Slides / 檔案搜尋、讀寫、協作: Primary: `google-drive:google-drive`; Supporting: `google-drive:google-docs`, `google-drive:google-sheets`, `google-drive:google-slides`
- Google Drive / 文件留言與協作審閱 / Docs、Sheets、Slides comments: Primary: `google-drive:google-drive-comments`; Supporting: `google-drive:google-docs`, `google-drive:google-sheets`
- Gmail / 信件搜尋、摘要、收件匣整理 / inbox triage、reply drafting context: Primary: `gmail:gmail`; Supporting: `gmail:gmail-inbox-triage`
- Google Calendar / 行程、空檔、會議準備 / schedule、availability、daily brief: Primary: `google-calendar:google-calendar`; Supporting: `google-calendar:google-calendar-daily-brief`, `google-calendar:google-calendar-group-scheduler`, `google-calendar:google-calendar-meeting-prep`
- Chrome / 使用者既有登入狀態 / cookies、extensions、真實分頁、Chrome-only QA: Primary: `chrome:control-chrome`; Supporting: `browser:control-in-app-browser`, `playwright`, `systematic-debugging`
- OpenAI / 官方產品與 API / 文件查證: Primary: `openai-docs`; Supporting: none
- Codex / 外掛與 Skill 管理 / 建立、安裝、驗證: Primary: `skill-creator`; Supporting: `skill-installer`, `plugin-creator`, `superpowers:writing-skills`

## 舊系統 / 盤點 / 整理

- Legacy / 規格反推 / 架構盤點: Primary: `spec-miner`; Supporting: `architecture-designer`, `code-documenter`, `mermaid-diagrams`
- Agent / Prompt / 檔案整理: Primary: `agent-md-refactor`; Supporting: `file-organizer`, `writing-clearly-and-concisely`
