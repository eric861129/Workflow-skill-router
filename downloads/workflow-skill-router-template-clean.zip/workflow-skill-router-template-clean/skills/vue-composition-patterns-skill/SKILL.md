---
name: vue-composition-patterns-skill
description: Use when designing, refactoring, or reviewing Vue 3 Composition API logic, composables, VueUse-style utilities, reactivity boundaries, watchers, lifecycle effects, shared state, route-aware logic, or reusable frontend behavior across components and packages.
---


# Vue Composition Patterns Skill

## Recommendation


## Purpose

Use this skill to keep Vue 3 logic readable, testable, and reusable. It complements:

- `vue-expert` for general Vue implementation.

## When to use

- A component has too much business logic, watcher logic, lifecycle work, or duplicated state handling.
- Logic should become a composable in an app or shared package.
- VueUse-style helpers may reduce custom code.
- Route, auth, permissions, i18n, storage, media query, clipboard, debounce, polling, or browser APIs are involved.
- A bug may come from stale refs, deep watchers, cleanup, effect timing, or mixed computed/mutable state.

## Composition rules

- Name composables by behavior: `usePermissionOptions`, `useStaffSelector`, `useRouteBackLink`.
- Keep composables narrow: one domain behavior or one reusable browser utility.
- Pass dependencies explicitly when it improves testability.
- Return readonly state unless callers are meant to mutate it.
- Prefer computed values over watchers when deriving state.
- Use watchers for effects, synchronization, and async triggers; clean up intervals, listeners, and subscriptions.
- Avoid global shared state unless the lifetime and reset behavior are explicit.
- Keep API calls, permission checks, and route decisions easy to test separately from rendering.

## VueUse-style guidance

- Prefer proven utilities for browser APIs, media queries, debouncing, storage, clipboard, element size, and event listeners when the dependency already exists or is approved.
- Do not add a dependency only to replace a few obvious lines.
- Wrap third-party utilities in project composables when business semantics matter.


- Keep app-specific composables inside the owning app until they are stable and business-neutral.
- Move to shared packages only when multiple apps need the same behavior.
- Respect route guards, feature tree, RBAC, and i18n message ownership.
- Use fake Traditional Chinese test data and avoid real personal data in unit tests.

## Verification

For extracted logic, prefer focused unit tests plus app typecheck:

```powershell
git diff --check
```

Use browser proof when the composable affects route behavior, layout, auth state, or user-visible interaction.
