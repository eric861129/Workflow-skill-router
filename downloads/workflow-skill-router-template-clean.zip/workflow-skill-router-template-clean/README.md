# Workflow Skill Router Template Package

This package is a public-safe skills pack generated from the maintainer's real
local Codex skill catalog.

## What is inside

- `skills/`: installable public-safe skill folders.
- `skills/workflow-skill-router/`: a sanitized copy of the maintainer's actual router.
- `MANIFEST.md`: included skill folders and sanitization notes.

Private organization-specific skills are excluded. Private lines inside otherwise
public skills are omitted during packaging.

## Install

Extract the contents of `skills/` into your Codex skills directory.

For Codex on Windows, the install target is usually:

```text
C:\Users\<you>\.codex\skills
```
